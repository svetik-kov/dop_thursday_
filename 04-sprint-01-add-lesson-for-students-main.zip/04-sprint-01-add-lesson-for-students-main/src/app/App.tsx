import './App.css'
import { Decks } from '../features/decks/Decks.tsx'

export const App = () => {
  return (
    <div>
      <Decks />
    </div>
  )
}
