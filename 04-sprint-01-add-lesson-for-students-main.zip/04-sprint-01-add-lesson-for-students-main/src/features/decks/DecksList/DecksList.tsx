import s from './DecksList.module.css'

export const DecksList = () => {
  return <ul className={s.list}></ul>
}
